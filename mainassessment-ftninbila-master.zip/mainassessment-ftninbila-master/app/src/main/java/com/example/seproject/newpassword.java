package com.example.seproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class newpassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newpassword);
    }
}